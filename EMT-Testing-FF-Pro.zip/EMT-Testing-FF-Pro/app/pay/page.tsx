"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";

type PlanId = "monthly" | "annual" | "lifetime";

const PLAN_DETAILS: Record<
  PlanId,
  { label: string; price: string; sublabel: string; highlight: string[] }
> = {
  monthly: {
    label: "Monthly",
    price: "$19/mo",
    sublabel: "Best for quick prep",
    highlight: ["Unlimited CAT simulator", "Full station drills", "Readiness dashboard"],
  },
  annual: {
    label: "Annual",
    price: "$119/yr",
    sublabel: "Save 48% vs monthly",
    highlight: ["Everything in monthly", "12 months of updates", "Priority support"],
  },
  lifetime: {
    label: "Lifetime",
    price: "$249 once",
    sublabel: "One-time payment",
    highlight: ["Never pay again", "All future content", "Lifetime access badge"],
  },
};

declare global {
  interface Window {
    Stripe?: (key: string) => {
      initEmbeddedCheckout: (options: { clientSecret: string }) => Promise<{
        mount: (selector: string) => void;
        unmount: () => void;
      }>;
    };
  }
}

async function loadStripe() {
  if (window.Stripe) return window.Stripe;
  await new Promise<void>((resolve, reject) => {
    const existing = document.querySelector("script[data-stripe]");
    if (existing) {
      existing.addEventListener("load", () => resolve());
      existing.addEventListener("error", () => reject(new Error("Stripe failed to load")));
      return;
    }
    const script = document.createElement("script");
    script.src = "https://js.stripe.com/v3/";
    script.async = true;
    script.dataset.stripe = "true";
    script.onload = () => resolve();
    script.onerror = () => reject(new Error("Stripe failed to load"));
    document.body.appendChild(script);
  });
  return window.Stripe;
}

export default function PaywallPage() {
  const router = useRouter();
  const [plan, setPlan] = useState<PlanId>("annual");
  const [email, setEmail] = useState("");
  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const checkoutRef = useRef<{ unmount: () => void } | null>(null);

  const publishableKey = useMemo(
    () => process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY || "",
    []
  );

  useEffect(() => {
    return () => {
      checkoutRef.current?.unmount();
      checkoutRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (!clientSecret) return;
    if (!publishableKey) {
      setError("Missing Stripe publishable key.");
      return;
    }
    let isActive = true;
    setError("");

    loadStripe()
      .then((Stripe) => {
        if (!Stripe) throw new Error("Stripe failed to initialize.");
        return Stripe(publishableKey).initEmbeddedCheckout({ clientSecret });
      })
      .then((checkout) => {
        if (!isActive) return;
        checkoutRef.current?.unmount();
        checkout.mount("#embedded-checkout");
        checkoutRef.current = checkout;
      })
      .catch((err: Error) => {
        if (!isActive) return;
        setError(err.message || "Unable to load Stripe.");
      });

    return () => {
      isActive = false;
    };
  }, [clientSecret, publishableKey]);

  const startCheckout = async () => {
    setError("");
    setIsLoading(true);
    setClientSecret(null);

    try {
      if (email.trim()) {
        localStorage.setItem("proEmail", email.trim());
      }
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ plan, email }),
      });
      const data = await res.json();
      if (!res.ok || !data?.clientSecret) {
        throw new Error(data?.error || "Unable to start checkout.");
      }
      setClientSecret(data.clientSecret);
    } catch (err: any) {
      setError(err?.message || "Unable to start checkout.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <main className="min-h-screen bg-[#0F172A] text-white px-6 py-12">
      <div className="mx-auto max-w-6xl">
        <div className="flex flex-col gap-8 lg:flex-row lg:items-start lg:gap-12">
          <section className="flex-1 space-y-6">
            <div>
              <span className="inline-flex items-center rounded-full border border-cyan-400/30 bg-cyan-500/10 px-3 py-1 text-[10px] font-bold uppercase tracking-[0.25em] text-cyan-200">
                Pro Access
              </span>
              <h1 className="mt-4 text-4xl font-black tracking-tight">
                Unlock the full NREMT simulator + pro study system.
              </h1>
              <p className="mt-3 text-slate-300">
                Get unlimited CAT-style simulations, mastery tracking, and detailed station drills. Choose the plan
                that fits your prep timeline.
              </p>
            </div>

            <div className="grid gap-4 sm:grid-cols-3">
              {(Object.keys(PLAN_DETAILS) as PlanId[]).map((key) => {
                const detail = PLAN_DETAILS[key];
                const selected = key === plan;
                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => setPlan(key)}
                    className={`rounded-2xl border px-4 py-5 text-left transition ${
                      selected
                        ? "border-cyan-400 bg-cyan-500/10 shadow-[0_0_40px_-20px_rgba(34,211,238,0.7)]"
                        : "border-white/10 bg-slate-900/40 hover:border-white/20"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-sm font-bold text-white">{detail.label}</div>
                        <div className="text-[11px] text-slate-400">{detail.sublabel}</div>
                      </div>
                      <div className="text-lg font-black text-white">{detail.price}</div>
                    </div>
                    <ul className="mt-4 space-y-1 text-[11px] text-slate-300">
                      {detail.highlight.map((item) => (
                        <li key={item}>• {item}</li>
                      ))}
                    </ul>
                  </button>
                );
              })}
            </div>

            <div className="rounded-2xl border border-white/10 bg-slate-900/50 p-5">
              <label className="text-[11px] font-semibold uppercase tracking-[0.2em] text-slate-400">
                Email for receipt + login
              </label>
              <input
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                placeholder="you@example.com"
                type="email"
                className="mt-3 w-full rounded-xl border border-white/10 bg-slate-950/70 px-4 py-3 text-sm text-white outline-none transition focus:border-cyan-400/60"
              />
              <p className="mt-2 text-[11px] text-slate-500">
                Use the same email you want attached to your pro access.
              </p>
            </div>

            {error ? (
              <div className="rounded-2xl border border-red-500/40 bg-red-500/10 p-4 text-sm text-red-200">
                {error}
              </div>
            ) : null}

            <div className="flex flex-col gap-3 sm:flex-row">
              <button
                onClick={startCheckout}
                className="flex-1 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-500 px-6 py-4 text-sm font-black uppercase tracking-widest text-white shadow-lg"
                disabled={isLoading}
              >
                {isLoading ? "Starting checkout..." : "Continue to checkout →"}
              </button>
              <button
                onClick={() => router.push("/dashboard")}
                className="rounded-2xl border border-white/10 bg-white/5 px-6 py-4 text-xs font-bold uppercase tracking-widest text-slate-200"
              >
                Not now
              </button>
            </div>

            <div className="text-[11px] text-slate-500">
              Secure checkout powered by Stripe. Cancel anytime on subscription plans.
            </div>
          </section>

          <section className="w-full max-w-lg rounded-3xl border border-white/10 bg-slate-900/60 p-6 shadow-[0_0_45px_-20px_rgba(34,211,238,0.45)]">
            <div className="text-sm font-bold text-white">Stripe Checkout</div>
            <p className="mt-2 text-xs text-slate-400">
              Your checkout form appears below after you start the signup.
            </p>
            <div
              id="embedded-checkout"
              className="mt-4 min-h-[480px] rounded-2xl border border-white/10 bg-slate-950/60"
            />
          </section>
        </div>
      </div>
    </main>
  );
}
